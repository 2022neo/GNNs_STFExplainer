import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv,GATConv
import torch_geometric
from torch_geometric import nn
from torch_geometric.data import InMemoryDataset
from torch_geometric.utils import to_dense_adj,to_dense_batch, dense_to_sparse
from torch_geometric.nn.dense import dense_mincut_pool, dense_diff_pool

class GCN_BAHShapes(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, label_dim, num_layers, pre_fc_count, post_fc_count, dropout=0.0, no_act=False, add_self_loops=True,mix_pool=False,hierarchical_pool=None):
        super(GCN_BAHShapes, self).__init__()
        assert num_layers>0
        self.dropout = dropout
        self.no_act = no_act
        self.mix_pool=mix_pool
        self.convs = torch.nn.ModuleList()
        self.convs.append(GCNConv(input_dim, hidden_dim, add_self_loops=add_self_loops, dropout=dropout))
        for _ in range(num_layers-1):
            self.convs.append(GCNConv(hidden_dim, hidden_dim, add_self_loops=add_self_loops, dropout=dropout))
        if self.mix_pool:
            self.mix_pool_fc = torch.nn.Linear(2*hidden_dim, hidden_dim)
        self.post_lin_list = torch.nn.ModuleList()
        for i in range(post_fc_count):
            lin = torch.nn.Linear(hidden_dim, hidden_dim)
            self.post_lin_list.append(lin)
            
        self.pre_lin_list = torch.nn.ModuleList()
        for i in range(pre_fc_count):
            lin = torch.nn.Linear(hidden_dim, hidden_dim)
            self.pre_lin_list.append(lin)
        self.lin_out = torch.nn.Linear(hidden_dim, label_dim)
        
        self.pooling_loss = None
        if hierarchical_pool=='mincut':
            print('use hierarchical_pool mincut')
            self.hierarchical_pool = MinCutPoolLayer(hidden_dim,20)
        elif hierarchical_pool=='diff':
            print('use hierarchical_pool diff')
            self.hierarchical_pool = DiffPoolLayer(hidden_dim,20)
        else:
            self.hierarchical_pool = None
            print('not using hierarchical pool')
            return
        self.mlp = torch.nn.Linear(hidden_dim, 50)

    def forward(self, data=None,adj=None):
        batch = data.batch
        x = self.get_emb(data, adj=adj)

        for i in range(len(self.pre_lin_list)):
            x = self.pre_lin_list[i](x)
            if not self.no_act:
                x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
            
        if self.mix_pool:
            x1 = getattr(torch_geometric.nn, 'global_max_pool')(x, batch)
            x2 = getattr(torch_geometric.nn, 'global_add_pool')(x, batch)
            x = self.mix_pool_fc(torch.concat([x1,x2],dim=-1))
        else:
            x = getattr(torch_geometric.nn, 'global_max_pool')(x, batch)
            
        
        for i in range(len(self.post_lin_list)):
            x = self.post_lin_list[i](x)
            if not self.no_act:
                x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        
        x = self.lin_out(x)
        x = x.softmax(-1)
                
        if x.shape[1] == 1:
            return x.view(-1)
        else:
            return x
        
    def get_emb(self, data, adj=None):
        x=data.x
        if adj is None:
            edge_weight = data.edge_weight
            edge_index = data.edge_index
        else:
            if len(adj.shape)<=1:
                edge_index = data.edge_index
                edge_weight = adj
            else:
                edge_mask = adj[list(data.edge_index)]>0
                edge_index = data.edge_index[:,edge_mask]
                edge_weight = adj[list(edge_index)]
            
        x = self.convs[0](x, edge_index=edge_index,edge_weight=edge_weight)
        x = self.convs[1](x, edge_index=edge_index,edge_weight=edge_weight)
        # if isinstance(self.hierarchical_pool,torch.nn.Module):
        #     x, edge_index, edge_weight, batch, self.pooling_loss = self.hierarchical_pool(x, edge_index, edge_weight=edge_weight,batch=batch)
        for i in range(2,len(self.convs)):
            x = self.convs[i](x, edge_index=edge_index,edge_weight=edge_weight)
            if not self.no_act:
                x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        return x
    
    def merge_emb(self, x, batch=None):
        for i in range(len(self.pre_lin_list)):
            x = self.pre_lin_list[i](x)
            if not self.no_act:
                x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
            
        if self.mix_pool:
            x1 = getattr(torch_geometric.nn, 'global_max_pool')(x, batch)
            x2 = getattr(torch_geometric.nn, 'global_add_pool')(x, batch)
            x = self.mix_pool_fc(torch.concat([x1,x2],dim=-1))
        else:
            x = getattr(torch_geometric.nn, 'global_max_pool')(x, batch)
            
        
        for i in range(len(self.post_lin_list)):
            x = self.post_lin_list[i](x)
            if not self.no_act:
                x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        return x
        

    def classify(self, x):

        x = self.lin_out(x)
        x = x.softmax(-1)
                
        if x.shape[1] == 1:
            return x.view(-1)
        else:
            return x

    def loss(self, pred, label):
        pred_loss = F.cross_entropy(pred, label, reduction='sum')
        loss = pred_loss if self.pooling_loss is None else pred_loss + self.pooling_loss
        return loss



class MinCutPoolLayer(torch.nn.Module):
    def __init__(self, input_dim,num_cluster):
        super(MinCutPoolLayer, self).__init__()
        self.mlp = torch.nn.Linear(input_dim, num_cluster)
        
    def forward(self, x, edge_index, edge_weight=None,batch=None):
        dense_x, mask = to_dense_batch(x, batch)
        dense_s = self.mlp(dense_x)
        dense_adj = to_dense_adj(edge_index=edge_index, batch=batch, edge_attr=edge_weight, max_num_nodes=dense_x.shape[1])
        dense_out, dense_out_adj, mincut_loss, ortho_loss = dense_mincut_pool(x=dense_x,adj=dense_adj,s=dense_s,mask=mask)
        out_edge_index,out_edge_weight = dense_to_sparse(dense_out_adj)
        new_batch_size, new_batch_nodes, num_feas = dense_out.shape
        out_x = dense_out.view(-1,num_feas)
        batch_indices = torch.arange(new_batch_size).unsqueeze(1)
        out_batch = batch_indices.repeat(1, new_batch_nodes).view(-1).to(out_x.device)
        pooling_loss = mincut_loss + ortho_loss
        return out_x, out_edge_index, out_edge_weight, out_batch, pooling_loss
    
class DiffPoolLayer(torch.nn.Module):
    def __init__(self, input_dim,num_cluster):
        super(DiffPoolLayer, self).__init__()
        self.mlp = torch.nn.Linear(input_dim, num_cluster)
        
    def forward(self, x, edge_index, edge_weight=None,batch=None):
        dense_x, mask = to_dense_batch(x, batch)
        dense_s = self.mlp(dense_x)
        dense_adj = to_dense_adj(edge_index=edge_index, batch=batch, edge_attr=edge_weight, max_num_nodes=dense_x.shape[1])
        dense_out, dense_out_adj, link_loss, ent_loss = dense_diff_pool(x=dense_x,adj=dense_adj,s=dense_s,mask=mask)
        out_edge_index,out_edge_weight = dense_to_sparse(dense_out_adj)
        new_batch_size, new_batch_nodes, num_feas = dense_out.shape
        out_x = dense_out.view(-1,num_feas)
        batch_indices = torch.arange(new_batch_size).unsqueeze(1)
        out_batch = batch_indices.repeat(1, new_batch_nodes).view(-1).to(out_x.device)
        pooling_loss = link_loss + ent_loss
        return out_x, out_edge_index, out_edge_weight, out_batch, pooling_loss

class BAHierarchicalShapesDataset(InMemoryDataset):
    def __init__(self, data_list, transform=None, pre_transform=None):
        super().__init__('', transform, pre_transform)

        if self.pre_filter is not None:
            data_list = [data for data in data_list if self.pre_filter(data)]

        if self.pre_transform is not None:
            data_list = [self.pre_transform(data) for data in data_list]
        self.data, self.slices = self.collate(data_list)