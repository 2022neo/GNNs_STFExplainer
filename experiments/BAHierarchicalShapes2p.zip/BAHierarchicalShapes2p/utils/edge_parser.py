import pickle
import numpy as np

def get_explain_labels(dataset_path):
    selected_gid = []
    selected_edge_labels = []
    with open(dataset_path,'rb') as f:
        edge_index_list,feats,labels,node_ids = pickle.load(f)
    for gid, (edge_index,graph_label,node_cls) in enumerate(zip(edge_index_list,labels,node_ids)):
        if graph_label==0: 
            continue
        edge_labels = []
        for edge in edge_index:
            edge_label = [0,0]
            if 'pf' in str(node_cls[edge[0]]) and 'pf' in str(node_cls[edge[1]]) :
                edge_label[1]=1
            if 'pw' in str(node_cls[edge[0]]) and 'pw' in str(node_cls[edge[1]]) :
                edge_label[0]=1
            if 'ph' in str(node_cls[edge[0]]) and 'ph' in str(node_cls[edge[1]]) :
                edge_label[0]=1
            edge_labels.append(edge_label)
        selected_edge_labels.append(edge_labels)
        selected_gid.append(gid)
    return selected_gid,selected_edge_labels

def get_knowledge_tree(dataset_path, selected_gid):
    assign_trees = []
    with open(dataset_path,'rb') as f:
        edge_index_list,feats,labels,node_ids = pickle.load(f)
    for gid in selected_gid:
        edge_index,graph_label, node_cls = edge_index_list[gid],labels[gid],node_ids[gid]
        cluster_id = 0
        cluster_mapping = {}
        assign_list = []
        for n in node_cls:
            if not isinstance(n,str):
                assign_list.append('-1')
            elif '-' not in n and 'pf' in n:
                assign_list.append(n)
            else:
                assign_list.append(n.split('-')[0].split('_')[0] )

        for name in np.unique(assign_list):
            cluster_mapping[name]=cluster_id
            cluster_id+=1
        tree = {1:[cluster_mapping[n] for n in assign_list]}
        assign_trees.append(tree)
    return assign_trees