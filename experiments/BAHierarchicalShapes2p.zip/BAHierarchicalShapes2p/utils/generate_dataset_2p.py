import networkx as nx
from networkx.generators import random_graphs, lattice, small, classic
import numpy as np

def disjoint_merge_graphs(g1, g2, nb_random_edges=1):
    g12 = nx.union(g1,g2)
    for i in range(nb_random_edges):
        e1 = list(g1.nodes())[np.random.randint(0,len(g1.nodes()))]
        e2 = list(g2.nodes())[np.random.randint(0,len(g2.nodes()))]
        g12.add_edge(e1,e2)        
    return g12

def joint_merge_graphs(proto_graph, shape_graph, proto_merge_node):
    mapping_proto = dict()
    mapping_shape = dict()
    shape_merge_node = list(shape_graph.nodes())[np.random.randint(0,len(shape_graph.nodes()))]
    mapping_shape[shape_merge_node] = f"{shape_merge_node}-{proto_merge_node}"
    mapping_proto[proto_merge_node] = f"{shape_merge_node}-{proto_merge_node}"
    shape_graph = nx.relabel_nodes(shape_graph,mapping_shape)
    proto_graph = nx.relabel_nodes(proto_graph,mapping_proto)
    proto_graph = nx.compose(proto_graph,shape_graph)
    return proto_graph

def reset_nodes(g,prefix:str):
    mapping = dict()
    i=0
    for n in g.nodes():
        mapping[n] = f"{prefix}{i}"
        i = i + 1
    return nx.relabel_nodes(g,mapping)

def get_shapes(r):
    if r == 0:
        return classic.wheel_graph(6)
    elif r == 1:
        return small.house_graph()
    else:
        raise

def generate_proto_graph(is_class1:bool,frame_dim=2):
    # Proto is a hierarchical structure that represents a square frame with at least one node replaced
    proto_graph = lattice.hypercube_graph(frame_dim)
    proto_graph = reset_nodes(proto_graph,'pf_')
    frame_nodes = np.array(proto_graph.nodes())
    np.random.shuffle(frame_nodes)
    frame_nodes = frame_nodes[:np.random.randint(1,len(frame_nodes)+1)]
    if is_class1:
        num_fix = len(frame_nodes)//2 + len(frame_nodes)%2 # class1's proto : num_house>=num_wheel
        shape_fix = 1
    else:
        num_fix = len(frame_nodes)//2 + 1 # class0's proto : num_wheel>num_house
        shape_fix = 0 
    for i,merge_node in enumerate(frame_nodes):
        if i < num_fix:
            r = shape_fix
        else:
            r = np.random.randint(0,2)
        shape_graph = get_shapes(r)
        shape_prefix = f'pw{i}_' if r == 0 else f'ph{i}_'
        shape_graph = reset_nodes(shape_graph,shape_prefix)
        proto_graph = joint_merge_graphs(proto_graph,shape_graph,merge_node.item())
    return proto_graph

def generate_class0(nb_random_edges, nb_node_ba=100):
    num_append = np.random.randint(5)
    append_shapes = []
    for i in range(num_append):
        r = np.random.randint(0,2)
        shape_graph = get_shapes(r)
        shape_prefix = f'w{i}_' if r == 0 else f'h{i}_'
        shape_graph = reset_nodes(shape_graph,shape_prefix)
        nb_node_ba -= len(shape_graph.nodes())
        append_shapes.append(shape_graph)
    
    r = np.random.randint(4)
    if r == 0:
        class_0_graph = random_graphs.barabasi_albert_graph(nb_node_ba, 1)
    elif r == 1:
        frame_graph = lattice.hypercube_graph(2)
        frame_graph = reset_nodes(frame_graph,'f_')
        nb_node_ba -= len(frame_graph.nodes())
        basic_graph = random_graphs.barabasi_albert_graph(nb_node_ba, 1)
        class_0_graph = disjoint_merge_graphs(frame_graph,basic_graph,nb_random_edges)
    elif r >= 2:
        proto_graph = generate_proto_graph(is_class1=False)
        nb_node_ba -= len(proto_graph.nodes())
        basic_graph = random_graphs.barabasi_albert_graph(nb_node_ba, 1)
        class_0_graph = disjoint_merge_graphs(proto_graph,basic_graph,nb_random_edges)
    for shape_graph in append_shapes:
        class_0_graph = disjoint_merge_graphs(class_0_graph,shape_graph,nb_random_edges)
    return class_0_graph
        
def generate_class1(nb_random_edges, nb_node_ba=100):
    num_append = np.random.randint(5)
    append_shapes = []
    for i in range(num_append):
        r = np.random.randint(0,2)
        shape_graph = get_shapes(r)
        shape_prefix = f'w{i}_' if r == 0 else f'h{i}_'
        shape_graph = reset_nodes(shape_graph,shape_prefix)
        nb_node_ba -= len(shape_graph.nodes())
        append_shapes.append(shape_graph)
        
    proto_graph = generate_proto_graph(is_class1=True)
    nb_node_ba -= len(proto_graph.nodes())
    basic_graph = random_graphs.barabasi_albert_graph(nb_node_ba, 1)
    class_1_graph = disjoint_merge_graphs(proto_graph,basic_graph,nb_random_edges)
    
    for shape_graph in append_shapes:
        class_1_graph = disjoint_merge_graphs(class_1_graph,shape_graph,nb_random_edges)
    return class_1_graph
        
def generate_samples(num_samples):
    assert num_samples % 2 == 0
    edge_index_list = []
    labels = []
    feats = []
    node_ids = []
    nb_node_ba = 100

    for _ in range(int(num_samples/2)):
        g = generate_class1(nb_random_edges=1, nb_node_ba=nb_node_ba)
        rand_ind = np.array(range(len(g.nodes())))
        np.random.shuffle(rand_ind)
        mapping = {node : i for i,node in zip(rand_ind,g.nodes())}
        edge_ind = [(mapping[edge[0]],mapping[edge[1]]) for edge in g.edges()]
        reverse_edge_ind = [(e[1],e[0]) for e in edge_ind]
        edge_ind.extend(reverse_edge_ind)
        edge_index_list.append(list(set(edge_ind)))
        node_ids.append([ele[0] for ele in sorted(mapping.items(),key=lambda x : x[1])])
        labels.append(1)
        feats.append(np.ones((len(g.nodes()),10))/10)

    for _ in range(int(num_samples/2)):
        g = generate_class0(nb_random_edges=1, nb_node_ba=nb_node_ba)
        rand_ind = np.array(range(len(g.nodes())))
        np.random.shuffle(rand_ind)
        mapping = {node : i for i,node in zip(rand_ind,g.nodes())}
        edge_ind = [(mapping[edge[0]],mapping[edge[1]]) for edge in g.edges()]
        reverse_edge_ind = [(e[1],e[0]) for e in edge_ind]
        edge_ind.extend(reverse_edge_ind)
        edge_index_list.append(list(set(edge_ind)))
        node_ids.append([ele[0] for ele in sorted(mapping.items(),key=lambda x : x[1])])
        labels.append(0)
        feats.append(np.ones((len(g.nodes()), 10))/10)
    return edge_index_list,feats,labels,node_ids

def generate_dataset(num_samples):
    edge_index_list,feats,labels,node_ids = generate_samples(num_samples)
    # data_list=[]
    # for edge_index,feat,label,node_id in zip(edge_index_list,feats,labels,node_ids):
    #         data = Data(x=torch.Tensor(feat), 
    #                     edge_index=torch.tensor(edge_index, dtype=torch.long).T, 
    #                     num_nodes=len(feat),
    #                     y=torch.tensor([int(label)], dtype=torch.long),
    #                     node_id=node_id,
    #                     )
    #         data_list.append(data)
    return edge_index_list,feats,labels,node_ids

